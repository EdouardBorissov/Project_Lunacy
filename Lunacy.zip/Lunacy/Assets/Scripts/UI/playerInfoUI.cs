﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class playerInfoUI : playerStats
{
    private Text playerHealthText;
    private playerHealth playerHealthInfo;
   
    void Start()
    {
        playerHealthInfo = GameObject.Find("Player").GetComponent<playerHealth>();
        playerHealthText = gameObject.GetComponent<Text>();
    }
    void Update()
    {
        playerHealthText.text = "Health: " + playerHealthInfo.getCurrentPlayerHealth().ToString() + "/" + playerHealthInfo.getMaxPlayerHealth().ToString();

    }
}
