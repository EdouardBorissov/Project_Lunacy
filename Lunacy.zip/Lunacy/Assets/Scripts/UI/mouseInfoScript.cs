﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class mouseInfoScript : playerStats {
    private Text mouseText;
    // Use this for initialization
    void Start () {
		mouseText = gameObject.GetComponent<Text>();
    }
	
	// Update is called once per frame
	void Update () {
        setMouseCoordinates();
        mouseText.text = "Mouse x = " + getMouseCoordinates().x + " Mouse y = " +  getMouseCoordinates().y;
    }
}
