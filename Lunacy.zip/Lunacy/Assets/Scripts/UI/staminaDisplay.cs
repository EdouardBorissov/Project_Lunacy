﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class staminaDisplay : playerStats
{
    private Text playerStamina;
    private playerMovement playerMovementInfo;
   

    void Start () {
        playerStamina = gameObject.GetComponent<Text>();
        playerMovementInfo = GameObject.Find("Player").GetComponent<playerMovement>();
	}
	

	void Update () {
        playerStamina.text = "Stamina: " + playerMovementInfo.getCurrentPlayerStamina().ToString() + "/" + playerMovementInfo.getMaxPlayerStamina().ToString();
    }
}
