﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class currentAttackDisplay : playerStats {
   private Text currentAttack;
    
    // Use this for initialization
    void Start () {
        currentAttack = gameObject.GetComponent<Text>();
    }
	
	// Update is called once per frame
	void FixedUpdate () {
        setMouseCoordinates();
        displayAttack(getMouseCoordinates().y);
    }


    public void displayAttack(float directionFacing)
    {

    if(directionFacing > 0.9)
    {
            currentAttack.text = "High Attack";
    }
    else if(directionFacing < 0.9 && directionFacing > -0.9)
    {
            currentAttack.text = "Middle Attack";
    }
    else if(directionFacing < -0.9)
    {
            currentAttack.text = "Low Attack";
    }

    }



}
