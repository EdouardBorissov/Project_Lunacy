﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyWeaponAttributes : MonoBehaviour {
    public float enemyWeaponDamage;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (gameObject.name == "Sword")
        {
            enemyWeaponDamage = 5;
        }
        else if (gameObject.name == "Spear")
        {
            enemyWeaponDamage = 3;
        }
        else if (gameObject.name == "Axe")
        {
            enemyWeaponDamage = 7;
        }

        else if (gameObject.name == "Hammer")
        {
            enemyWeaponDamage = 9;
        }
    }

   
}

