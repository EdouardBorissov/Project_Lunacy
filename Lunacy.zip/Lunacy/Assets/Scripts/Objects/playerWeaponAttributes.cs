﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerWeaponAttributes : MonoBehaviour {

public float playerWeaponDamage;

	// Use this for initialization
	void Start () {
		
    



    }
	
	// Update is called once per frame
	void Update () {
        if (gameObject.name == "Sword")
        {
            playerWeaponDamage = 5;
        }
        else if (gameObject.name == "Spear")
        {
            playerWeaponDamage = 3;
        }
        else if (gameObject.name == "Axe")
        {
            playerWeaponDamage = 7;
        }

        else if (gameObject.name == "Hammer")
        {
            playerWeaponDamage = 9;
        }
    }
}
