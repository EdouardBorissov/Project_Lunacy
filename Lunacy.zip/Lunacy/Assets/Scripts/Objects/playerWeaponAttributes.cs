﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerWeaponAttributes : MonoBehaviour {

    private float weaponDamage;
	// Use this for initialization
	void Start () {
       
    }
	
	// Update is called once per frame
	void Update () {
        if (gameObject.tag == "playerSword")
        {
           setWeaponDamage(5);
        }
        else if (gameObject.name == "playerSpear")
        {
            setWeaponDamage(3);
        }
        else if (gameObject.name == "playerAxe")
        {
            setWeaponDamage(7);
        }

        else if (gameObject.name == "playerHammer")
        {
            setWeaponDamage(10);
        }
    }


    public void setWeaponDamage(float newWeaponDamage)
    {
        weaponDamage = newWeaponDamage;
    }

    public float getWeaponDamage()
    {
        return weaponDamage;
    }
}
