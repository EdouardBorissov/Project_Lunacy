﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyAI : MonoBehaviour
{
    Rigidbody2D enemyRigidbody;
    public float moveSpeed;
    public float patrolLength;
    public int directionFacing = 1;
    private int patrolCounter;
    private int rand;
    bool canPatrol = true;
    //public enemyAttack enemyAttackScript;
    public Transform playerLocation;

    /// <summary>
    /// ///////////////////enemy attack

    public Collider2D enemyWeaponCollider;
    public Animator enemyAnimator;




    // Use this for initialization
    void Start()
    {
        enemyRigidbody = gameObject.GetComponent<Rigidbody2D>();
        StartCoroutine(patrolDirection(patrolLength));
       

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        patrol();
        rand = Random.Range(0, 3);
       
    }


    public void patrol()
    {
        if (canPatrol)
        {
            enemyRigidbody.velocity = new Vector3(directionFacing * moveSpeed * Time.deltaTime, enemyRigidbody.velocity.y);
        }
    }



   


    /// //////////////////////////////////////////////////////////////////////////////////////////////////
    /// //////////////////////////////////////////////////////////////////////////////////////////////////
    /// //////////////////////////////////////////////////////////////////////////////////////////////////
    void OnTriggerStay2D(Collider2D trig)
    {

        if (trig.gameObject.tag == "Player")
        {
            playerLocation = trig.GetComponent<Transform>();
            if (playerLocation.position.x > gameObject.transform.position.x)
            {
                // Debug.Log("First If triggered");
                canPatrol = false;

                directionFacing = 1;
                moveSpeed = 100;
                enemyRigidbody.velocity = new Vector3(directionFacing * moveSpeed * Time.deltaTime, enemyRigidbody.velocity.y);

                if (Vector3.Distance(playerLocation.position, gameObject.transform.position) < 2)
                {
                    //Debug.Log("First Layered If triggered");
                   enemyAttackMethod(rand);
                    moveSpeed = 10;
                    enemyRigidbody.velocity = new Vector3(directionFacing * moveSpeed * Time.deltaTime, enemyRigidbody.velocity.y);

                }


            }
            else if (playerLocation.position.x < gameObject.transform.position.x)
            {
                canPatrol = false;
                directionFacing = -1;
                moveSpeed = 100;
                enemyRigidbody.velocity = new Vector3(directionFacing * moveSpeed * Time.deltaTime, enemyRigidbody.velocity.y);
                if (Vector3.Distance(playerLocation.position, gameObject.transform.position) < 2)
                {
                    enemyAttackMethod(rand);
                    moveSpeed = 10;
                    enemyRigidbody.velocity = new Vector3(directionFacing * moveSpeed * Time.deltaTime, enemyRigidbody.velocity.y);

                }

            }
        }
    }
    /// //////////////////////////////////////////////////////////////////////////////////////////////////
    /// ////////////////////////////////////////////////////////////////////////////////////////////////// /// //////////////////////////////////////////////////////////////////////////////////////////////////
    /// //////////////////////////////////////////////////////////////////////////////////////////////////
    void OnTriggerExit2D(Collider2D trig)
    {
        canPatrol = true;
        StartCoroutine(patrolDirection(patrolLength));
    }

    IEnumerator patrolDirection(float patrolLength)
    {

        while (canPatrol)
        {

            yield return new WaitForSeconds(patrolLength);
            if (canPatrol)
            {
                directionFacing *= -1;
                patrolCounter++;
                Vector3 flip = transform.localScale;
                flip.x *= -1;
                transform.localScale = flip;
            }
        }

    }



/// ///////////////////////////////////////////enemy attack



    public void enemyAttackMethod(int rand)
    {
        if (rand == 0)
        {
            enemyAnimator.SetTrigger("attack1");
        }

        else if (rand == 1)
        {
            enemyAnimator.SetTrigger("attack2");
        }

        else if (rand == 2)
        {
            enemyAnimator.SetTrigger("attack3");
        }

    }

    /// ///////////////////////////////////////////////////

    public void enemyAttackLethal()
    {
        enemyWeaponCollider.enabled = true;
    }

    public void enemyAttackReset()
    {
        enemyWeaponCollider.enabled = false;
        enemyAnimator.ResetTrigger("attack1");
    }
    public void enemyAttackReset1()
    {
        enemyWeaponCollider.enabled = false;
        enemyAnimator.ResetTrigger("attack2");
    }
    public void enemyAttackReset2()
    {
        enemyWeaponCollider.enabled = false;
        enemyAnimator.ResetTrigger("attack3");
    }
}
