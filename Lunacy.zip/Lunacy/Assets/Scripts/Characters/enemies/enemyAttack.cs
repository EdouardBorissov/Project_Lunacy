﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyAttack : MonoBehaviour
{

    Collider2D enemyWeaponCollider;
   public Animator enemyAnimator;
    // Use this for initialization
    void Start()
    {
         
       // enemyAnimator = this.GetComponent<Animator>();
       // enemyWeaponCollider = gameObject.GetComponent<Collider2D>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void enemyAttackMethod(int rand)
    {
        if (rand == 0)
        {
            enemyAnimator.SetTrigger("attack1");
        }

        else if (rand == 1)
        {
            enemyAnimator.SetTrigger("attack2");
        }

        else if (rand == 2)
        {
            enemyAnimator.SetTrigger("attack3");
        }

    }
    
    /// ///////////////////////////////////////////////////
    
   public void enemyAttackLethal()
    {
        enemyWeaponCollider.enabled = true;
    }

    public void enemyAttackReset()
    {
        enemyWeaponCollider.enabled = false;
        enemyAnimator.ResetTrigger("attack1");
    }
    public void enemyAttackReset1()
    {
        enemyWeaponCollider.enabled = false;
        enemyAnimator.ResetTrigger("attack2");
    }
    public void enemyAttackReset2()
    {
        enemyWeaponCollider.enabled = false;
        enemyAnimator.ResetTrigger("attack3");
    }
}