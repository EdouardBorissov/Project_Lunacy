﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyHealth : MonoBehaviour {
    public float enemyHealthAmount;
    public float invincibilityFrames = 2;
    private float healthBarDamage;
    private float playerWeaponDamage;
    public Transform enemyHealthBar;
    public playerWeaponAttributes playerWeaponStuff;
    public Transform playerLocation;
    // Use this for initialization
    void Start () {
        //enemyHealthBar = GameObject.FindGameObjectWithTag("enemyHealthBar").GetComponent<Transform>();
        playerLocation = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (enemyHealthAmount <= 0)
        {
            Destroy(gameObject);
        }
    }

    void OnCollisionEnter2D(Collision2D col)
    {

        if (col.gameObject.tag == "playerSword")
        {
            playerWeaponStuff = col.gameObject.GetComponent<playerWeaponAttributes>();
            playerWeaponDamage = playerWeaponStuff.getWeaponDamage();
            healthBarDamage = (playerWeaponDamage / enemyHealthAmount * enemyHealthBar.localScale.x);
            takeDamage();
        }
    }


    /// /////////////////////////////////

    public void takeDamage()
    {
        enemyHealthAmount -= playerWeaponDamage;
        Debug.Log("Enemy took: " + playerWeaponDamage + " and now has : " + enemyHealthAmount + " health! ");
        Vector2 newEnemyHealthBar = enemyHealthBar.localScale;
        newEnemyHealthBar.x -= (healthBarDamage);
        enemyHealthBar.localScale = newEnemyHealthBar;
        if (playerLocation.position.x < gameObject.transform.position.x)
        {
            transform.Translate(1, 0, 0);

        }
        else if (playerLocation.position.x > gameObject.transform.position.x)
        {
            transform.Translate(-1, 0, 0);

        }
        // Debug.Log("Enemy Health: " + enemyHealth);


    }
}
