﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class testEnemyHealth : MonoBehaviour {
    public float enemyHealth;
    public float invincibilityFrames = 2;
    playerWeaponAttributes playerWeaponStuff;
    private float playerWeaponDamage;
    public Transform enemyHealthBar;
    private float healthBarDamage;
    public Transform playerLocation;
	// Use this for initialization
	void Start () {
        playerWeaponStuff = GameObject.FindGameObjectWithTag("playerWeapon").GetComponent<playerWeaponAttributes>();
        playerWeaponDamage = playerWeaponStuff.playerWeaponDamage;
        healthBarDamage = (playerWeaponDamage/enemyHealth);
      enemyHealthBar = GameObject.FindGameObjectWithTag("enemyHealthBar").GetComponent<Transform>();
        playerLocation = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        }
	
	// Update is called once per frame
	void Update () {
		if(enemyHealth <= 0)
        {
        //insert death animation here
            Destroy(gameObject);
        }
	}

    void OnCollisionEnter2D(Collision2D coll)
    {
       // Debug.Log("Enemy Was Hit");
        if(coll.gameObject.tag == "playerWeapon")
        {
            StartCoroutine(takeDamage(invincibilityFrames));
        }
    }

    IEnumerator takeDamage(float invincibilityFrames)
    {
        enemyHealth -= playerWeaponDamage;
       Vector2 newEnemyHealthBar = enemyHealthBar.localScale;
        newEnemyHealthBar.x -= (healthBarDamage);
        enemyHealthBar.localScale = newEnemyHealthBar;
        transform.Translate(3, 0, 0);
       // Debug.Log("Enemy Health: " + enemyHealth);

        yield return new WaitForSeconds(invincibilityFrames);
    }
}
