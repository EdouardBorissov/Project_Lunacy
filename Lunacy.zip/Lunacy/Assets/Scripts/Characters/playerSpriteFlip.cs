﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerSpriteFlip : MonoBehaviour {
    private Vector2 directionFacing;
    bool isFlipped = false;
   
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 mouseLocation = Input.mousePosition;
        mouseLocation = Camera.main.ScreenToWorldPoint(mouseLocation);

        directionFacing = new Vector2(mouseLocation.x - transform.position.x, mouseLocation.y - transform.position.y);

        //Debug.Log(directionFacing.x + " is directionFacing");
      // Debug.Log(gameObject.transform.position.x + "is transform.position.x");
        if (directionFacing.x < 0 && isFlipped == false)
        {
            flip();
            isFlipped = true;
            //Debug.Log(isFlipped);
        }
        else if(directionFacing.x > 0 && isFlipped == true)
        {
            flip();
            isFlipped = false;
           // Debug.Log(isFlipped);
        }
    }

    public void flip()//only flips parent, not the wand
    {
        
            Vector3 flip = transform.localScale;
            flip.x *= -1;
            transform.localScale = flip;
            
    }
}
