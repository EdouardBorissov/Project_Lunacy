﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class characterAttack : MonoBehaviour {
    Collider2D playerWeapon;
    Animator characterAnimator;
	// Use this for initialization
	void Start () {
        playerWeapon = GameObject.FindGameObjectWithTag("playerWeapon").GetComponent<Collider2D>();
        characterAnimator = this.GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
		if(Input.GetButtonDown("Fire1"))
        {
         //   Debug.Log("Sword Should Swing");
            characterAnimator.SetTrigger("attack");
        }
	}


    public void attackWithWeapon()
    {
        playerWeapon.enabled = true;
    }

    public void notAttackWithWeapon()
    {
        playerWeapon.enabled = false;
        characterAnimator.ResetTrigger("attack");
    }
}
