﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class characterAttack : playerStats {

    [SerializeField]
    private Collider2D playerWeapon;
    private playerMovement playerMovementInfo;
    // Use this for initialization
    void Start () {
        characterAnimator = gameObject.GetComponent<Animator>();
        playerMovementInfo = GameObject.Find("Player").GetComponent<playerMovement>();
        if(playerWeapon == null)
        {
            Debug.Log("PLAYER WEAPON NOT FOUND");
        }
       
	}
	
	// Update is called once per frame
	void FixedUpdate () {
        setMouseCoordinates();
        if (Input.GetButtonDown("Fire1")&& getMouseCoordinates().y > 0.9 && playerMovementInfo.getCurrentPlayerStamina() >= 15)
        {
            characterAnimator.SetTrigger("attack1");
            playerMovementInfo.setCurrentPlayerStamina(playerMovementInfo.getCurrentPlayerStamina() - 15);
        }

       else if(Input.GetButtonDown("Fire1") && getMouseCoordinates().y < 0.9 && getMouseCoordinates().y > -0.9 && playerMovementInfo.getCurrentPlayerStamina() >= 15)
       {
            characterAnimator.SetTrigger("attack2");
            playerMovementInfo.setCurrentPlayerStamina(playerMovementInfo.getCurrentPlayerStamina() - 15);
        }

       else if (Input.GetButtonDown("Fire1") && getMouseCoordinates().y < -0.9 && playerMovementInfo.getCurrentPlayerStamina() >= 15)
       {
            characterAnimator.SetTrigger("attack3");
            playerMovementInfo.setCurrentPlayerStamina(playerMovementInfo.getCurrentPlayerStamina() - 15);
        }
	}


    public void attackWithWeapon()
    {
        playerWeapon.enabled = true;
    }

    public void notAttack1WithWeapon()
    {
        playerWeapon.enabled = false;
        characterAnimator.ResetTrigger("attack1");
    }

    public void notAttack2WithWeapon()
    {
        playerWeapon.enabled = false;
        characterAnimator.ResetTrigger("attack2");
    }
    public void notAttack3WithWeapon()
    {
        playerWeapon.enabled = false;
        characterAnimator.ResetTrigger("attack3");
    }
}
