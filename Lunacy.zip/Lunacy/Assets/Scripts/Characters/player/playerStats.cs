﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerStats : MonoBehaviour {
    [SerializeField]
    protected float maxHealth;
    [SerializeField]
    protected float currentHealth;
    [SerializeField]
    protected float speed;
    [SerializeField]
    protected float maxStamina;
    [SerializeField]
    protected float currentStamina;
    [SerializeField]
    protected float dodgeDistance;
    [SerializeField]
    protected float staminaRegenAmount;
    protected float playerWeaponDamage;
    protected Rigidbody2D rigidBody;
    protected Vector2 mouseCoordinates;
    protected Animator characterAnimator;
    

    /// ///////////////////////////////////////////////////
    /// ///////////////////////////////////////////////////
    void Start () {
        rigidBody = gameObject.GetComponent<Rigidbody2D>();
        
    }
    /// ///////////////////////////////////////////////////
    /// ///////////////////////////////////////////////////
 
    void FixedUpdate () {
       
       
    }
    /// ///////////////////////////////////////////////////
    /// //mouse coordinates related functions
    /// ///////////////////////////////////////////////////
    public Vector2 getMouseCoordinates()
    {
        return mouseCoordinates;
    }
    public void setMouseCoordinates()
    {
        Vector2 mouseLocation = Input.mousePosition;
        mouseLocation = Camera.main.ScreenToWorldPoint(mouseLocation);
        mouseCoordinates = new Vector2(mouseLocation.x - transform.position.x, mouseLocation.y - transform.position.y);
    }
    /// ///////////////////////////////////////////////////
    /// //health related functions
    /// ///////////////////////////////////////////////////
    public float getMaxPlayerHealth()
    {
        return maxHealth;
    }
    public void setMaxPlayerHealth(float newMaxHealth)
    {
        maxHealth = newMaxHealth;
    }
    public float getCurrentPlayerHealth()
    {
        return currentHealth;
    }
    public void setCurrentPlayerHealth(float newCurrentHealth)
    {
        currentHealth = newCurrentHealth;
    }
    /// ///////////////////////////////////////////////////
    /// //speed related functions
    /// ///////////////////////////////////////////////////
    public float getPlayerSpeed()
    {
        return speed;
    }
    /// ///////////////////////////////////////////////////
    /// //dodge related functions
    /// ///////////////////////////////////////////////////
   
    public float getDodgeDistance()
    {
        return dodgeDistance;
    } 
   
    /// ///////////////////////////////////////////////////
    /// //stamina related functions
    /// ///////////////////////////////////////////////////
    public float getMaxPlayerStamina()
    {
        return maxStamina;
    }
    public void setMaxPlayerStamina(float newMaxStamina)
    {
        maxStamina = newMaxStamina;
    }
    public float getCurrentPlayerStamina()
    {
        return currentStamina;
    } 
    public void setCurrentPlayerStamina(float newCurrentStamina)
    {
        currentStamina = newCurrentStamina;
    }

    public float getStaminaRegenAmount()
    {
        return staminaRegenAmount;
    }

    /// ///////////////////////////////////////////////////
    /// //weaponDamage related functions
    /// ///////////////////////////////////////////////////
    public float getWeaponDamage()
    {
        return playerWeaponDamage;
    }
    public void setWeaponDamage(float newPlayerWeaponDamage)
    {
        playerWeaponDamage = newPlayerWeaponDamage;
    }



}
