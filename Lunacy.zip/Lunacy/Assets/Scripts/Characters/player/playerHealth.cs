﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class playerHealth : playerStats
{
    private enemyWeaponAttributes enemyWeaponScript;
    private float enemyWeaponDamage;



    void Update()
    {
        if (getCurrentPlayerHealth() <= 0)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.tag == "enemyWeapon")
        {
            enemyWeaponScript = col.gameObject.GetComponent<enemyWeaponAttributes>();
            enemyWeaponDamage = enemyWeaponScript.enemyWeaponDamage;
            // Debug.Log("Player Was Hit");
            takeDamage();
        }
    }

    public void takeDamage()
    {
        setCurrentPlayerHealth(getCurrentPlayerHealth() - enemyWeaponDamage);
        Debug.Log("Player Health: " + getCurrentPlayerHealth());
    }
}
