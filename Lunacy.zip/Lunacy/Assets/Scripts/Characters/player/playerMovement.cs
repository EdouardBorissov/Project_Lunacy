﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerMovement : playerStats
{
    private bool canJump = false;
    private int hasFlipped = 1;
   

    // Use this for initialization
    void Start()
    {
        characterAnimator = gameObject.GetComponent<Animator>();
        rigidBody = gameObject.GetComponent<Rigidbody2D>();
        StartCoroutine(staminaRegen(getStaminaRegenAmount()));
    }
    // Update is called once per frame
    void FixedUpdate()
    {
        
        setMouseCoordinates();
        idleAnimSetter(getMouseCoordinates().y);
        currentDirectionFacing();
        movement();
        Debug.Log("The y axis for the mouse is " + getMouseCoordinates().y);
    }

    public void movement()
    {
        float horizontal = Input.GetAxis("Horizontal");
        if (horizontal != 0)
        {
            characterAnimator.SetTrigger("running");
            rigidBody.velocity = new Vector3(horizontal * speed * Time.deltaTime * 30, rigidBody.velocity.y);
        }
        else if(horizontal == 0)
        {
            characterAnimator.ResetTrigger("running");
        }
        dodge();
        jump();
    }

    /// //////////////////////////////////////////////////////////////////////////////

   
    public void jump()
    {
        if (Input.GetKey(KeyCode.Space) && canJump)
        {
            Vector2 jumpVector = new Vector2(rigidBody.velocity.x, 400);
            rigidBody.AddForce(jumpVector);
            canJump = false;
        }
    }
    public void dodge()
    {
        if (Input.GetKeyDown(KeyCode.LeftShift) && canJump && getCurrentPlayerStamina()>=25)
        {
            
            characterAnimator.SetTrigger("dodge");
           
            rigidBody.velocity = new Vector2(dodgeDistance * -hasFlipped, 5);
            setCurrentPlayerStamina(getCurrentPlayerStamina() - 25 ); 

        }
     
    }
    /// //////////////////////////////////////////////////////////////////////////////
    /// 
    public IEnumerator staminaRegen(float staminaRegenAmount)
    {
        while (true)
        {
            
            setCurrentPlayerStamina(getCurrentPlayerStamina() + staminaRegenAmount);
            if (getCurrentPlayerStamina() > getMaxPlayerStamina())
            {
                setCurrentPlayerStamina(getMaxPlayerStamina());
            }
            yield return new WaitForSeconds(1);

        }
    }
    /// 
    /// //////////////////////////////////////////////////////////////////////////////
    public void currentDirectionFacing()
    {
        if (getMouseCoordinates().x < 0 && hasFlipped == 1)
        {
            Vector3 flip = transform.localScale;
            flip.x *= -1;
            transform.localScale = flip;
            hasFlipped *= -1;

        }
        else if (getMouseCoordinates().x > 0 && hasFlipped == -1)
        {
            Vector3 flip = transform.localScale;
            flip.x *= -1;
            transform.localScale = flip;
            hasFlipped *= -1;

        }
    }
    /// //////////////////////////////////////////////////////////////////////////////
    /// //////////////////////////////////////////////////////////////////////////////
    /// 
    void OnCollisionEnter2D(Collision2D col)
    {

        if (col.gameObject.tag == "ground")
        {
            canJump = true;
        }
    }
    ////////////////////////////////////////////////////////////////////////////


    void idleAnimSetter(float mouseYLocation)
    {
        if (mouseYLocation > 0.9)
        {
            characterAnimator.ResetTrigger("idleMiddle");
            characterAnimator.ResetTrigger("idleDown");
            characterAnimator.SetTrigger("idleUp");
        }
        else if (mouseYLocation < 0.9 && mouseYLocation > -0.9)
        {
            
            characterAnimator.ResetTrigger("idleUp");
            characterAnimator.ResetTrigger("idleDown");
            characterAnimator.SetTrigger("idleMiddle");
        }
        else if (mouseYLocation < -0.9)
        {
            characterAnimator.ResetTrigger("idleUp");
            characterAnimator.ResetTrigger("idleMiddle");
            characterAnimator.SetTrigger("idleDown");
        }
    }
}



