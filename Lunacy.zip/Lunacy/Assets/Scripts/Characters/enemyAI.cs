﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyAI : MonoBehaviour {
    Rigidbody2D enemyRigidbody;
    public float moveSpeed;
    public int directionFacing = 1;
    public float patrolLength;
    private int patrolCounter;
    public Transform playerLocation;
    bool canPatrol = true;
    // Use this for initialization
    void Start () {
        enemyRigidbody = gameObject.GetComponent<Rigidbody2D>();
        StartCoroutine(patrolDirection(patrolLength));

    }
	
	// Update is called once per frame
	void FixedUpdate () {
        enemyRigidbody.velocity = new Vector3(directionFacing * moveSpeed * Time.deltaTime, 0);
        //  Debug.Log("Text Message for enemy AI");
     
       
           
       
           }

    void OnTriggerStay2D(Collider2D trig)
    {
        if (trig.gameObject.tag == "Player")
        {
            playerLocation = trig.gameObject.GetComponent<Transform>();
            if (playerLocation.position.x > gameObject.transform.position.x)
            {
                canPatrol = false;
                directionFacing = 1;
                Debug.Log("Heather is the cutest");

            }
            else if(playerLocation.position.x < gameObject.transform.position.x)
            {
                canPatrol = false;
                directionFacing = -1;
                Debug.Log("Heather is the cutest");
            }
        }
    }


        IEnumerator patrolDirection(float patrolLength)
    {

        while (canPatrol)
        {

            yield return new WaitForSeconds(patrolLength);
            if (canPatrol)
            {
                directionFacing *= -1;
                patrolCounter++;
                // Debug.Log(patrolCounter);
                Vector3 flip = transform.localScale;
                flip.x *= -1;
                transform.localScale = flip;
            }
        }
        
    }
}
