﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerMovement : MonoBehaviour {
    private Rigidbody2D rigidBody;
    bool canJump = false;
    public float jumpForce;
    public float moveSpeed;
    

	// Use this for initialization
	void Start () {
        rigidBody = gameObject.GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {

        movement();
		
	}

    public void movement()
    {
        if (Input.GetKey(KeyCode.Space) && (canJump == true))
        {
            canJump = false;
            rigidBody.velocity = new Vector2(rigidBody.velocity.x, jumpForce);

        }
        
        float horizontal = Input.GetAxis("Horizontal");

        rigidBody.velocity = new Vector3(horizontal * moveSpeed * Time.deltaTime * 30, rigidBody.velocity.y);
    }

    /// //////////////////////////////////////////////////////////////////////////////

    void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.tag == "ground")
        {
            canJump = true;
        }
    }
    
    }


    
